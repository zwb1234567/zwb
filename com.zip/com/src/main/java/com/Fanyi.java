package com;



import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

public class Fanyi {
	private  String key;
	private  String ID ;
	private  String Url;
	private  String query;
	private  String to;
	
	public Fanyi(String flag,String query) {
		super();
		this.key = "0rmPFCDbfJfvUgPWn15A";;
		this.ID  = "20200604000486054";
		this.Url ="http://api.fanyi.baidu.com/api/trans/vip/translate";
		this.query = query;
		if(flag.equals("1"))
		{
			this.to = "en";
		}
		else
		{
			this.to = "zh";
		}
	}
	
	public String translate() throws Exception
	{
		CloseableHttpClient httpclient = HttpClients.createDefault(); 	
		HttpPost HttpPost = new HttpPost(Url);
		//设置POST参数
		List<BasicNameValuePair> parameters = new ArrayList<BasicNameValuePair>();
		parameters.add(new BasicNameValuePair("q",query));
		parameters.add(new BasicNameValuePair("from","auto"));
		parameters.add(new BasicNameValuePair("to",to));
		parameters.add(new BasicNameValuePair("appid",ID));
		String salt = String.valueOf(System.currentTimeMillis());
		parameters.add(new BasicNameValuePair("salt",salt));
		String src = ID + query + salt + key; 
		parameters.add(new BasicNameValuePair("sign",MD5.md5(src)));
		
		UrlEncodedFormEntity formEntity = new UrlEncodedFormEntity(parameters,"UTF-8");
		HttpPost.setEntity(formEntity);
		
		CloseableHttpResponse response = null;
		try{
			response = httpclient .execute(HttpPost);
			if(response.getStatusLine().getStatusCode() == 200)
			{
				String json = EntityUtils.toString(response.getEntity(), "utf-8");	
				//System.out.println(content);
			    // json解析器，解析json数据
			    JsonParser parser = new JsonParser();
			    JsonElement element = parser.parse(json);
			    // json属于对象类型时
			    if (element.isJsonObject()) {  
			        JsonObject object = element.getAsJsonObject();  // 转化为对象
			        // 1. value为string时，取出string
			        // String target = object.get("to").getAsString();
			        //System.out.println("翻译成" + target);
			        // 2. value为array时，取出array
			        JsonArray trans_result = object.getAsJsonArray("trans_result");  // 
			        for (int i = 0; i < trans_result.size(); i++) {
			        	JsonObject  result = (JsonObject) trans_result.get(i);
			            String dst = result.get("dst").getAsString();
			            //String recourse = result.get("src").getAsString();
					    return dst;
			        }
			        // 3. value为object时，取出object
			        /*JsonObject introduce = object.getAsJsonObject("trans_result");
			        String name = introduce.get("dst").getAsString();
			        //int age = introduce.get("age").getAsInt();
			        System.out.println("结果" + name);*/
			    }
			}
				return "";
		}finally
		{
			if(response != null)
			{
				response.close();
			}
			httpclient.close();
		}
	}



}
