package com;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class Huilv {
	private String APP_KEY = "518cf79ff8e6a498ec727673048507ad";
	//http://op.juhe.cn/onebox/exchange/query?key=
	
	
	public Huilv()
	{
		
	}
	
	public void get_huilv()  throws Exception
	{
		CloseableHttpClient httpclient = HttpClients.createDefault(); 
    	HttpGet get = new HttpGet("http://op.juhe.cn/onebox/exchange/query?key=" + APP_KEY);
    	CloseableHttpResponse response = null;
    	try{
			response = httpclient .execute(get);
			if(response.getStatusLine().getStatusCode() == 200)
			{
				HttpEntity entity = response.getEntity(); 
				String json = EntityUtils.toString(entity, "utf-8");
			    JsonParser parser = new JsonParser();
			    JsonElement element = parser.parse(json);
			    //System.out.println(json);   
			    JsonObject object = element.getAsJsonObject(); 
			    JsonObject result = object.getAsJsonObject("result");
			    String date = result.get("update").getAsString();
			    System.out.println("\n时间：" + date);
			    JsonArray all = result.getAsJsonArray("list");
			    for(int i = 0;i < all.size();i ++)
			    {
			    	JsonArray every = all.get(i).getAsJsonArray();
			    	System.out.println( "\n货币名称："+every.get(0).getAsString()+ "\n交易单位：" + every.get(1).getAsString() + 
			    			"\n现汇买入价：" + every.get(2).getAsString() + "\n现钞买入价：" + every.get(3).getAsString() + 
			    			"\n现钞卖出价：" + every.get(4).getAsString() + "\n中行折算价：" + every.get(5).getAsString());
			    }
			    System.out.println();
			}
			return;
		}finally
		{
			if(response != null)
			{
				response.close();
			}
			httpclient.close();
		}
	}
}
