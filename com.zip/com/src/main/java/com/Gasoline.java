package com;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class Gasoline {
	private String province ;
    private String URL = "http://apis.juhe.cn/gnyj/query";
    private String APP_KEY = "b7b591cad4c31e7fbc021e2cdf4da86a";
    
    public Gasoline(String province){
    	this.province = province;
    }
    
    public String getPrice() throws Exception
    {
    	CloseableHttpClient httpclient = HttpClients.createDefault(); 
    	HttpGet get = new HttpGet("http://apis.juhe.cn/gnyj/query?key=" + APP_KEY);
    	CloseableHttpResponse response = null;
    	try{
			response = httpclient .execute(get);
			if(response.getStatusLine().getStatusCode() == 200)
			{
				HttpEntity entity = response.getEntity(); 
				String json = EntityUtils.toString(entity, "utf-8");
			    JsonParser parser = new JsonParser();
			    JsonElement element = parser.parse(json);
			    //System.out.println(json);   
			    JsonObject object = element.getAsJsonObject(); 
			    JsonArray all = object.getAsJsonArray("result");
			    for(int i = 0;i < all.size();i ++)
			    {
			    	String result_pro = all.get(i).getAsJsonObject().get("city").getAsString();
			    	if(province.equals(result_pro))
			    	{
			    		JsonObject obj = all.get(i).getAsJsonObject();
			    		return "\n省份："+obj.get("city").getAsString() +"\n92号油："+ obj.get("92h").getAsString()+"元/L" +
			    				"\n95号油："+obj.get("95h").getAsString() +"元/L"+ "\n98号油："+obj.get("98h").getAsString()+"元/L"
			    				+ "\n0号油：   " + obj.get("0h").getAsString()+"元/L";
			    	}
			    }
			    
			}
			return "";
		}finally
		{
			if(response != null)
			{
				response.close();
			}
			httpclient.close();
		}
    }
}
