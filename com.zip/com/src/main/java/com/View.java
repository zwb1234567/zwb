package com;



import java.util.Scanner;

public class View {
	private String parameter1;
	private String parameter2;

	
	private Scanner input = new Scanner(System.in);
	
	public View() {
		super();
	}

	public void Selected() throws Exception{
		String choice1;	
		int choice;
		do{
		System.out.println("*****当前位置>>生活百宝箱主页*****");		
		System.out.println("     1.天气预报查询");
		System.out.println("     2.中英文双向翻译");
		System.out.println("     3.IP地址来源查询");
		System.out.println("     4.手机号码归属查询");
		System.out.println("     5.省份油价查询");
		System.out.println("     6.常用汇率查询");
		System.out.println("     0.退出程序");
		System.out.print("请输入你的选择：");
		choice1= input.next();
		choice = Integer.parseInt(choice1);
		switch(choice)
		{
		case 0:
			System.out.println("\n主人再见啦！\n程序结束！谢谢使用！");			
			return;
		case 1:
			chooseCity();
			returnMain();
			break;
		case 2:
			Selected_fanyi();
			dis_translate();
			returnMain();
			break;
		case 3:
			inputIp();
			returnMain();
			break;
		case 4:
			inputPhone();
			returnMain();
			break;
		case 5:
			Choose_Province();
			returnMain();
			break;
		case 6:
			Search_huilv();
			returnMain();
			break;
		default:
			System.out.println("请输入有效选择！");		
		}
		}while(choice!= 0 );
	}
	
	public void Selected_fanyi()
	{
		System.out.println("\n当前位置>>中英文双向翻译主页");
		System.out.println("请选择翻译方向");
		System.out.println("1：中文-->英文");
		System.out.println("2：英文-->中文");
		System.out.print("请输入选择：");
		this.parameter1 = input.next();
		if(parameter1 .equals("1"))
		{
			System.out.print("请输入你要翻译的中文文本:");
			this.parameter2 = input.next();
		}
		else if(parameter1 .equals("2"))
		{
			System.out.print("请输入你要翻译的英文文本:");
			this.parameter2 = input.next();
		}
		else
		{
			System.out.println("请输入有效选择！");
			Selected_fanyi();
		}
	}	
	public void dis_translate() throws Exception
	{
		Fanyi f = new Fanyi(parameter1,parameter2);
		System.out.println("主人,小的正在为你努力翻译中.....！");
		System.out.println("翻译结果：" + f.translate() + "\n");
	}
	
	public void chooseCity() throws Exception{
		System.out.print("请问主人需要查询那个城市的天气预报：");
		String city = input.next();
		Whether w = new Whether(city);
		w.getRequest();
	}
	
	public void returnMain(){
		System.out.println("请按回车键返回主菜单.....");
		input.nextLine();
		input.nextLine();
	}
	public void inputIp() throws Exception{
		System.out.println("提示：请输入正确的IP号，否则程序会抛出异常！\n"
				+ "测试所用Ip:117.152.24.102" + "  如果不知道自己IP号，可以在百度中输入‘IP地址查询’，可以查看到您的IP号！");
		System.out.print("请输入您要查询的IP号：");
		String ip = input.next();
		IP MyIp= new IP(ip);
		System.out.println("\nIP号为" + ip + "的详细信息如下：");
		System.out.println(MyIp.getIp());
	}
	public void inputPhone() throws Exception{
		System.out.print("请输入您要查询的电话号码(11位)：");
		String phone = input.next();
		if(phone.length()!= 11 )
		{
			System.out.println("输入的号码不正确！请确认无误后重试！");
			return;
		}
		PhoneNumber p = new PhoneNumber(phone);
		System.out.println("\n+++查询结果+++");
		System.out.println("手机号码段:" + phone +"\n"+ p.getPhone());
	}
	public void Choose_Province() throws Exception
	{
		System.out.println("提示：请按格式输入，例如：要查询湖北省的油价，输入湖北即可，不用输入‘省’字");
		System.out.print("请输入要查询的省份：");
		String province = input.next();
		Gasoline g = new Gasoline(province);
		String result = g.getPrice();
		if(result.equals(""))
		{
			System.out.println("查询失败！请按正确的格式输入正确的省份信息！");
		}
		else
		{
			System.out.println(result);
		}
	}
	
	public void Search_huilv() throws Exception
	{
		Huilv bank = new Huilv();
		bank.get_huilv();
	}
	public String getParameter1() {
		return parameter1;
	}


	public void setParameter1(String parameter1) {
		this.parameter1 = parameter1;
	}


	public String getParameter2() {
		return parameter2;
	}


	public void setParameter2(String parameter2) {
		this.parameter2 = parameter2;
	}
}
