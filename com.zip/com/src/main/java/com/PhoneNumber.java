package com;

import java.net.URI;
import java.net.URISyntaxException;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class PhoneNumber {
    private String URL = "http://apis.juhe.cn/mobile/get";
    //请求的key
    private String APP_KEY = "ca74f75c032799c74b84b5e7a8a5774d";
    private String phone;
    
    public PhoneNumber(){}
    public PhoneNumber(String phone){
    	this.phone = phone;
    }
    
    public String getPhone() throws Exception{
    	CloseableHttpClient httpclient = HttpClients.createDefault(); 
    	// HttpGet get = new HttpGet("http://apis.juhe.cn/mobile/get?phone=13429667914&key=***"); 
    	URIBuilder builder = new URIBuilder(URL);
    	builder.setParameter("phone", phone);
    	builder.setParameter("key",APP_KEY);
    	URI uri = builder.build();
    	HttpGet get = new HttpGet(uri);
    	CloseableHttpResponse response = null;
    	try{
			response = httpclient .execute(get);
			if(response.getStatusLine().getStatusCode() == 200)
			{
				HttpEntity entity = response.getEntity(); 
				String json = EntityUtils.toString(entity, "utf-8");
			    JsonParser parser = new JsonParser();
			    JsonElement element = parser.parse(json);
			    //System.out.println(json);
			    if (element.isJsonObject()) {  
			        JsonObject object = element.getAsJsonObject(); 
			        JsonObject result = object.getAsJsonObject("result");
			        String Province = result.get("province").getAsString();
			        String City = result.get("city").getAsString();
			        String areacode = result.get("areacode").getAsString();
			        String Isp = result.get("company").getAsString();
			        String zip = result.get("zip").getAsString();
			        if(zip.length() == 0)
			        {
			        	zip = "暂无信息";
			        }
			        String result_total =  "省份:" + Province + "\n城市:" + City +
			        		"\n运营商:" + Isp + "\n区号:" + areacode + "\n邮编:" + zip;
			        return result_total;
			    }
			}
			return "";
		}finally
		{
			if(response != null)
			{
				response.close();
			}
			httpclient.close();
		}
    }
}
