package com;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class IP {
    //请求的接口地址
    private String REQUEST_URL = "http://apis.juhe.cn/ip/ipNew";
    //请求的key
    private String APP_KEY = "5d2881e67a8b0df525595367e9e909f6";
    private String ip = "117.152.24.102" ;
    
    public IP(String ip)
    {
    	this.ip  = ip;
    }
    public IP(){}
    
    public String getIp() throws Exception{
    	CloseableHttpClient httpclient = HttpClients.createDefault(); 	
		HttpPost HttpPost = new HttpPost(REQUEST_URL);
		List<BasicNameValuePair> parameters = new ArrayList<BasicNameValuePair>();
		parameters.add(new BasicNameValuePair("ip",ip));
		parameters.add(new BasicNameValuePair("key",APP_KEY));
		UrlEncodedFormEntity formEntity = new UrlEncodedFormEntity(parameters,"UTF-8");
		HttpPost.setEntity(formEntity);
		CloseableHttpResponse response = null;
		try{
			response = httpclient .execute(HttpPost);
			if(response.getStatusLine().getStatusCode() == 200)
			{
				String json = EntityUtils.toString(response.getEntity(), "utf-8");
			    JsonParser parser = new JsonParser();
			    JsonElement element = parser.parse(json);
			    if (element.isJsonObject()) {  
			        JsonObject object = element.getAsJsonObject(); 
			        JsonObject result = object.getAsJsonObject("result");
			        String Country = result.get("Country").getAsString();
			        String Province = result.get("Province").getAsString();
			        String City = result.get("City").getAsString();
			        String Isp = result.get("Isp").getAsString();
			        String result_total = "国家:" + Country + "\n省份:" + Province + "\n城市:" + City + "\n运营商:" + Isp +"\n";
			        return result_total;
			    }
			}
			return "";
		}finally
		{
			if(response != null)
			{
				response.close();
			}
			httpclient.close();
		}
    }
 


}
