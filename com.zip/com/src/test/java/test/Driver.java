package test;

import com.*;

public class Driver {
	
	public static void main(String args[]) throws Exception
	{
		View v = new View();
		v.Selected();		
	}
}
